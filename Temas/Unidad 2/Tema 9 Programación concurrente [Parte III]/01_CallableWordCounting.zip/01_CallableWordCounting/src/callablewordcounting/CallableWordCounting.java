package callablewordcounting;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;

public class CallableWordCounting {

    public static Callable<Integer> wordCounter(String word, String file) {
        return () -> {
            try (Stream<String> stream = Files.lines(Paths.get(file))) {
                return stream
                        .mapToInt(line -> {
                            int count = 0;
                            int index = -1;
                            while ((index = line.indexOf(word, index + 1)) != -1) {
                                count++;
                            }
                            return count;
                        })
                        .sum();
            } catch (IOException ex) {
                System.err.println("Error reading " + file);
            }
            return 0;
        };
    }

    public static void main(String[] args) {
        String word = "alcohol";
        ExecutorService executor = Executors.newWorkStealingPool();
        List<Future<Integer>> futures;
        try {
            futures = executor.invokeAll(Arrays.asList(
                    wordCounter(word, "text1.txt"),
                    wordCounter(word, "text2.txt"),
                    wordCounter(word, "text3.txt")
            ));
            executor.shutdown();
            futures.forEach(future -> {
                try { // Blocks until all tasks have finished
                    System.out.println(future.get());
                } catch (InterruptedException | ExecutionException e) {
                    throw new IllegalStateException(e);
                }
            });
        } catch (InterruptedException ex) {
        }

    }

}
