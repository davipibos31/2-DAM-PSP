module com.example.getcompanies {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;


    opens com.example.getcompanies to javafx.fxml;
    exports com.example.getcompanies;
}