package edu.javier.productmanagerfx.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import edu.javier.productmanagerfx.model.Product;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

import java.lang.reflect.Type;
import java.util.List;

public class GetProducts extends Service<List<Product>> {
    String catId;

    public GetProducts(String catId) {
        this.catId = catId;
    }

    @Override
    protected Task<List<Product>> createTask() {
        return new Task<List<Product>>() {
            @Override
            protected List<Product> call() throws Exception {
                String json = ServiceUtils.getResponse(
                        NodeServer.getServer() + "/product/" + catId,
                        null, "GET");
                Gson gson = new Gson();
                Type type = new TypeToken<List<Product>>() {
                }.getType();
                List<Product> prods = gson.fromJson(json, type);
                return prods;
            }
        };
    }
}
