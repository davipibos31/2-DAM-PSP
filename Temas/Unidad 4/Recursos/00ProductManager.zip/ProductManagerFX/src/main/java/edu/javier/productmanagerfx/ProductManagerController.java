package edu.javier.productmanagerfx;

import edu.javier.productmanagerfx.model.Category;
import edu.javier.productmanagerfx.model.Product;
import edu.javier.productmanagerfx.services.*;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class ProductManagerController implements Initializable {
    
    @FXML private Button newProductBt;
    @FXML private Button saveProductBt;
    @FXML private Button deleteProductBt;
    
    @FXML private ListView<Category> categoryList;
    
    @FXML private TableView<Product> productsTable;
    
    @FXML private TableColumn<Product,String> productRefCol;
    @FXML private TableColumn<Product,String> productNameCol;
    @FXML private TableColumn<Product,Double> productPriceCol;
    
    @FXML private VBox productFieldsContainer;
    @FXML private ChoiceBox<Category> categoryChoice;
    @FXML private TextField referenceInput;
    @FXML private TextField nameInput;
    @FXML private TextField priceInput;
    
    @FXML private Label infoLabel;
    
    private ObservableList<Category> categories;
    private ObservableList<Product> currentProds;
    
    private FadeTransition infoFadeOut = null;
    private boolean infoFadeFinished = true;
    
    // WEB SERVICES
    private GetCategories getCats;
    private GetProducts getProds;
    private AddProduct addProd;
    private UpdateProduct updateProd;
    private DeleteProduct deleteProd;
    
    /**
     * Method called when the new product button is pressed.
     * Clears any product selection, shows and clears the fields of product's properties.
     */
    @FXML
    private void newProductAction(ActionEvent event) {
        productsTable.getSelectionModel().clearSelection();
        productFieldsContainer.setVisible(true);
        categoryChoice.getSelectionModel().select(
                categoryList.getSelectionModel().selectedIndexProperty().intValue());
        referenceInput.setText("");
        nameInput.setText("");
        priceInput.setText("");
        saveProductBt.setDisable(false);
    }
    
    /**
     * Method called when delete product button is pressed.
     * Ask the user to delete the current selected product. If affirmative, it deletes
     * the product from the file and from the product's list.
     */
    @FXML
    private void deleteProductAction(ActionEvent event) {
        Product selectedProd = productsTable.getSelectionModel().getSelectedItem();
        
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Delete product " + selectedProd.getReference());
        alert.setHeaderText("Delete the product '" +
                selectedProd.getName() + "' with reference: " + selectedProd.getReference());
        alert.setContentText("Are you ok with this?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            deleteProd = new DeleteProduct(selectedProd.getId());
            deleteProd.start();
            
            deleteProd.setOnSucceeded(e -> {
                if(deleteProd.getValue()) { // Success
                    currentProds.remove(selectedProd);
                    showInfoMsg("Product " + selectedProd.getReference() + " deleted.", false);
                } else {
                    showInfoMsg("Error removing the product", true);
                }
            });
        }
    }
    
    /**
     * Method called when the save product button is pressed.
     * Saves the selected product or adds it if none is selected.
     * Changes will be saved in file and product's list.
     */
    @FXML
    private void saveProductAction(ActionEvent event) {
        Product selectedProd = productsTable.getSelectionModel().getSelectedItem();
        int selectedIndex = productsTable.getSelectionModel().getSelectedIndex();
        try {
            Product newProd = new Product(Double.parseDouble(priceInput.getText().replace(",", ".")), 
                referenceInput.getText().trim(), nameInput.getText().trim(), categoryChoice.getValue().getId());
            
            if(newProd.getName().isEmpty() || newProd.getReference().isEmpty()) {
                showInfoMsg("There can't be empty fields.", true);
            } else {
                
                if(selectedIndex >= 0) { // Update
                    newProd.setId(selectedProd.getId());
                    updateProd = new UpdateProduct(newProd);
                    updateProd.start();
                    
                    updateProd.setOnSucceeded(e -> {
                        if(updateProd.getValue()) { // Success
                            selectNewCategory(categories.stream()
                                    .filter(c -> c.getId().equals(newProd.getIdCategory()))
                                    .findFirst().get(), newProd.getId());                            
                            showInfoMsg("Product updated successfully.", false);
                        } else {
                            showInfoMsg("Error updating the product", true);
                        }
                    });
                } else { // Add
                    addProd = new AddProduct(newProd);
                    addProd.start();
                    
                    addProd.setOnSucceeded(e -> {
                        String id = addProd.getValue();
                        if(!id.equals("")) { // Success
                            selectNewCategory(categories.stream()
                                    .filter(c -> c.getId().equals(newProd.getIdCategory()))
                                    .findFirst().get(), id);                            
                            showInfoMsg("New product added successfully.", false);
                        } else {
                            showInfoMsg("Error adding the product", true);
                        }
                    });
                }
            }
        } catch (NumberFormatException e) {
            showInfoMsg("Price format is not correct.", true);
        }
    }
    
    /**
     * Initializes the view and loads products.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initializeProdTable();        
        initializeCatList();
    }
    
    /**
     * Method called when a new category is selected from categories list.
     * Loads the products from that category and asigns them to the products TableView.
     * @param category The name of the category selected.
     * @para selectAfter After retrieving products, select the one with this id
     */
    private void selectNewCategory(Category category, String selectAfter) {
        getProds = new GetProducts(category.getId());
        getProds.start();
        getProds.setOnSucceeded(e -> {
            currentProds = FXCollections.observableArrayList(getProds.getValue());
            productsTable.setItems(currentProds);
            Optional<Product> selProd = currentProds.stream()
                    .filter(p -> p.getId().equals(selectAfter)).findFirst();
            if(selProd.isPresent()) {
                productsTable.getSelectionModel().select(selProd.get());
                productsTable.scrollTo(selProd.get());
            }
        });
    }
    
    /**
     * Initizalizes the categories ListView, adds event listener and selects first
     * category by default.
     */
    private void initializeCatList() {
        getCats = new GetCategories();
        getCats.start();
        
        getCats.setOnSucceeded(e -> {
            categories = FXCollections.observableArrayList(getCats.getValue());
            categoryList.setItems(categories);
            categoryChoice.setItems(categories);
            
            if(categories.size() > 0) {
                categoryList.getSelectionModel().select(0);
                newProductBt.setDisable(false);
            }
        });      
        
        categoryList.getSelectionModel().selectedIndexProperty().addListener(
                (ov, old_val, new_val) -> {
                    if(new_val.intValue() >=0 ) 
                        selectNewCategory(categoryList.getItems().get(new_val.intValue()), "");
                }
        );
    }
    
    /**
     * Initializes the products TableView. Binds Product class properties to its
     * columns stablishing a format for the price column. It also adds a listener for when a product is selected.
     */
    private void initializeProdTable() {
        productsTable.setPlaceholder(new Label("No products in this category"));
        
        productRefCol.setCellValueFactory(new PropertyValueFactory<>("reference"));
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        productPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        productPriceCol.setStyle( "-fx-alignment: CENTER-RIGHT;");
        
        productPriceCol.setCellFactory(col -> {  // How to show the price column's value
            return new TableCell<Product, Double>() {
                @Override
                protected void updateItem(Double price, boolean empty) {
                    super.updateItem(price, empty);
                    
                    if (price == null || empty) {
                        setText(null);
                    } else {
                        setText(String.format("%.2f€", price)); // product's price format
                    }
                }
            };
        });
        
        // A product is selected from the table
        productsTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                productFieldsContainer.setVisible(true);
                categoryChoice.getSelectionModel().select(
                        categoryList.getSelectionModel().selectedIndexProperty().intValue());
                referenceInput.setText(newSelection.getReference());
                nameInput.setText(newSelection.getName());
                priceInput.setText(String.format("%.2f", newSelection.getPrice()));
                saveProductBt.setDisable(false);
                deleteProductBt.setDisable(false);
            } else {
                productFieldsContainer.setVisible(false);
                saveProductBt.setDisable(true);
                deleteProductBt.setDisable(true);
            }
        });
    }
    
    /**
     * Shows a message to the user at the window's bottom.
     * @param msg The message to show
     * @param isError If the message is an error or just information.
     */
    private void showInfoMsg(String msg, boolean isError) {
        if(isError && !infoLabel.getStyleClass().contains("error")) {
            infoLabel.getStyleClass().add("error");
        } else if(!isError && infoLabel.getStyleClass().contains("error")) {
            infoLabel.getStyleClass().remove("error");
        }
        
        infoLabel.setText(msg);
        
        if(!infoFadeFinished) { // If a previous animation is running.
            infoFadeOut.stop();
        }
        
        // Fade out animation for the message after 2 seconds. Runs in different thread, does not block.
        infoFadeFinished = false;
        infoLabel.setOpacity(1.0);
        infoFadeOut = new FadeTransition(Duration.millis(2000), infoLabel);
        infoFadeOut.setFromValue(1.0);
        infoFadeOut.setToValue(0.0);
        infoFadeOut.setDelay(Duration.millis(3000));
        infoFadeOut.setOnFinished(e -> infoFadeFinished = true);
        infoFadeOut.play();
    }
    
}
