package edu.javier.productmanagerfx.services;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import edu.javier.productmanagerfx.model.Category;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

import java.lang.reflect.Type;
import java.util.List;

public class GetCategories extends Service<List<Category>> {
    @Override
    protected Task<List<Category>> createTask() {
        return new Task<List<Category>>() {
            @Override
            protected List<Category> call() throws Exception {
                String json = ServiceUtils.getResponse(
                        NodeServer.getServer() + "/category", null, "GET");
                Gson gson = new Gson();
                Type type = new TypeToken<List<Category>>() {
                }.getType();
                List<Category> cats = gson.fromJson(json, type);
                return cats;
            }
        };
    }
}
