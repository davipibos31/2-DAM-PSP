package edu.javier.productmanagerfx.model;

import com.google.gson.annotations.SerializedName;

public class Category {
    @SerializedName("_id")
    private String id;
    private String name;

    public String getId() {
        return id;
    }

    @Override
    public String toString() {
        return name;
    }
}
