package edu.javier.productmanagerfx.model;

import com.google.gson.annotations.SerializedName;

public class Product {
    @SerializedName("_id")
    private String id;
    private double price;
    private String name;
    @SerializedName("category")
    private String idCategory;
    private String reference;

    /**
     * Constructor
     * @param price Price
     * @param ref Reference
     * @param name Name
     * @param idCategory int
     */
    public Product(double price, String ref, String name, String idCategory) {
        this.price = price;
        this.reference = ref;
        this.name  = name;
        this.idCategory = idCategory;
        this.id = "";
    }

    /**
     * Returns the product's price
     * @return product's price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Returns the product's reference
     * @return product's reference
     */
    public String getReference() {
        return reference;
    }

    /**
     * Returns the product's name
     * @return product's name
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /**
     * Returns the product's category
     * @return product's category
     */
    public String getIdCategory() {
        return idCategory;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", REF: " + reference + ", NAME: " + name +
                ", PRICE: " + price;
    }
}

