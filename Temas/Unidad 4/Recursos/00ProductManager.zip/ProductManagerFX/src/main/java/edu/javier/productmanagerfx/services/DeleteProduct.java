package edu.javier.productmanagerfx.services;

import com.google.gson.Gson;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

public class DeleteProduct extends Service<Boolean> {
    String idProd;

    public DeleteProduct(String idProd) {
        this.idProd = idProd;
    }

    @Override
    protected Task<Boolean> createTask() {
        return new Task<Boolean>() {
            @Override
            protected Boolean call() throws Exception {
                Gson gson = new Gson();
//                String resp = ServiceUtils.getResponse(
//                        NodeServer.getServer() + "/product/"
//                                + idProd, null, "DELETE");
                String resp = ServiceUtils.getResponse(
                        "http://localhost:8080/product/" + idProd,
                        null, "DELETE");
                return Boolean.parseBoolean(resp);
            }
        };
    }
}
