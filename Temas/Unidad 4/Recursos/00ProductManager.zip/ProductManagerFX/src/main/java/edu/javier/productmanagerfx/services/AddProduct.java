package edu.javier.productmanagerfx.services;

import com.google.gson.Gson;
import edu.javier.productmanagerfx.model.Product;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

public class AddProduct extends Service<String> {
    Product prod;

    public AddProduct(Product prod) {
        this.prod = prod;
    }

    @Override
    protected Task<String> createTask() {
        return new Task<String>() {
            @Override
            protected String call() throws Exception {
                Gson gson = new Gson();
//                String resp = ServiceUtils.getResponse(
//                        NodeServer.getServer() + "/product",
                String resp = ServiceUtils.getResponse(
                        "http://localhost:8080/product",
                        gson.toJson(prod), "POST");
                return resp;
            }
        };
    }
}
