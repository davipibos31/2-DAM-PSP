package edu.javier.productmanagerfx.services;

public class NodeServer {

    public static String getServer() {
        return "http://192.168.0.170:8080";
    }

}
