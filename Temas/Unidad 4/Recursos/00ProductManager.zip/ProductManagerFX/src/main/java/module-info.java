module edu.javier.productmanagerfx {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;


    opens edu.javier.productmanagerfx to javafx.fxml;
    exports edu.javier.productmanagerfx;
}