package edu.javier.productmanagerfx.services;

import com.google.gson.Gson;
import edu.javier.productmanagerfx.model.Product;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

public class UpdateProduct extends Service<Boolean> {
    Product prod;

    public UpdateProduct(Product prod) {
        this.prod = prod;
    }

    @Override
    protected Task<Boolean> createTask() {
        return new Task<Boolean>() {
            @Override
            protected Boolean call() throws Exception {
                Gson gson = new Gson();
//                String resp = ServiceUtils.getResponse(
//                        NodeServer.getServer() + "/product/" +
//                                prod.getId(), gson.toJson(prod), "PUT");
                String resp = ServiceUtils.getResponse(
                        "http://localhost:8080/product/" + prod.getId(),
                        gson.toJson(prod), "PUT");
                return Boolean.parseBoolean(resp);
            }
        };
    }
}
