Run the command:

npm install

