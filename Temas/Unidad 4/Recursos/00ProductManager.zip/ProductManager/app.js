const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const Category = require('./models/category');
const Product = require('./models/product');


mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/product-manager',{useUnifiedTopology: true,useNewUrlParser: true});

let app = express();

app.use(bodyParser.json());

app.get('/category', (req, res) => {
    Category.find().then(result => {
        res.send(result);
    }).catch(error => {
        res.send([]);
    });
});

app.get('/product/:idCat', (req, res) => {
    Product.find({category: req.params.idCat}).then(result => {
        res.send(result);
    }).catch (error => {
        res.send([]);
    });
});

app.post('/product', (req, res) => {
    let newProduct = new Product({
        name: req.body.name,
        reference: req.body.reference,
        price: req.body.price,
        category: req.body.category
    });
    newProduct.save().then(result => {
        res.send(result._id);
    }).catch(error => {
        res.send("");
    });
});

app.put('/product/:id', (req, res) => {
    Product.findByIdAndUpdate(req.params.id, {$set: {name: req.body.name, reference: req.body.reference, price: req.body.price, category: req.body.category}}, {new: true}).then(result => {
        res.send(true);
    }).catch (error => {
        res.send(false);
    });
});

app.delete('/product/:id', (req, res) => {
    Product.findByIdAndRemove(req.params.id).then(result => {
        res.send(true);
    }).catch(error => {
        res.send(false);
    });
})

app.listen(8080);
