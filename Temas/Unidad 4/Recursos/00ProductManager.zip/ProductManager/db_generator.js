const mongoose = require('mongoose');

const Category = require('./models/category');
const Product = require('./models/product');

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/product-manager',{useUnifiedTopology: true,useNewUrlParser: true});

Product.collection.drop();
Category.collection.drop();

// 1. Components
let cat = new Category({name: 'Components'});
cat.save().then(result => {
    let prod = new Product({name: 'AMD A10-7850k', reference: '4032', price: 145.97, category: result._id});
    prod.save();
    let prod2 = new Product({name: 'AMD Radeon R9 Fury X', reference: '4203', price: 619, category: result._id});
    prod2.save();
    let prod3 = new Product({name: 'ASUS FM2+ Motherboard', reference: '2009', price: 65.95, category: result._id});
    prod3.save();        
    let prod4 = new Product({name: 'DVD-RW Drive', reference: '1034', price: 23.75, category: result._id});
    prod4.save();
});

// 2. Networking
let cat2 = new Category({name: 'Networking'});
cat2.save();

// 3. Peripherals
let cat3 = new Category({name: 'Peripherals'});
cat3.save().then(result => {
    let prod = new Product({name: 'Epson XP-322 Multifuntion Printer WIFI', reference: '3001', price: 55.65, category: result._id});
    prod.save();    
});

// 4. Services
let cat4 = new Category({name: 'Services'});
cat4.save().then(result => {
    let prod = new Product({name: 'Computer mounting', reference: '9999', price: 40, category: result._id});
    prod.save();    
});

// 5. Software
let cat5 = new Category({name: 'Software'});
cat5.save();
