const mongoose = require('mongoose');

let productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        minlength: 1,
        trim: true
    },
    reference: {
        type: String,
        required: true,
        trim: true
    },
    price: {
        type: Number
    },
    category: {
        type:  mongoose.Schema.Types.ObjectId, 
        ref: 'Category',
        required: true
    }    
});

let Product = mongoose.model('Product', productSchema);

module.exports = Product;