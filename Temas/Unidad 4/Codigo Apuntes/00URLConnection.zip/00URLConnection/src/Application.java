import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class Application {

    // Get charset encoding (UTF-8, ISO,...)
    public static String getCharset(String contentType) {
        for (String param : contentType.replace(" ", "").split(";")) {
            if (param.startsWith("charset=")) {
                return param.split("=", 2)[1];
            }
        }
        return null; // Probably binary content
    }


    public static void main(String[] args) {

        try {
            URL url = new URL("http://wikipedia.com");
            HttpURLConnection conn;
            //HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            //conn.setInstanceFollowRedirects(true);

            do {
                conn = (HttpURLConnection) url.openConnection();

                System.out.println(conn.getResponseCode());
                System.out.println(conn.getResponseMessage());
                System.out.println(conn.getHeaderFields());

                if (conn.getResponseCode() == 301) {
                    url = new URL(conn.getHeaderField("Location"));
                }
            } while (conn.getResponseCode() == 301);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//    public static void main(String[] args) {
//        BufferedReader bufferedReader = null;
//        try {
//            URL google = new URL("http://www.google.es");
//            URLConnection conn = google.openConnection();
//
//            String charset = getCharset(conn.getHeaderField("Content-Type"));
//
//            bufferedReader = new BufferedReader(new InputStreamReader(
//                    conn.getInputStream(),
//                    charset)
//            );
//
//            String line;
//
//            while ((line = bufferedReader.readLine()) != null) {
//                System.out.println(line);
//            }
//
//        } catch (MalformedURLException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            if (bufferedReader != null) {
//                try {
//                    bufferedReader.close();
//
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//        }
//    }
}
