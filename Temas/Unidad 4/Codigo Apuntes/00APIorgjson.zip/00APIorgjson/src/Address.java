import org.json.JSONObject;

public class Address {
    String city;
    String street;

    public Address(JSONObject addressJson) {
        city = addressJson.getString("city");
        street = addressJson.getString("street");
    }

    @Override
    public String toString() {
        return street + " ( " + city + " )";
    }
}
