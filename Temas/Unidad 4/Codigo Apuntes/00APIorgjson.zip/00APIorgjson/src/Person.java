import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Person {
    String name;
    int age;
    List<Address> address;

    public Person(JSONObject personJson) {
        name = personJson.getString("name");
        age = personJson.getInt("age");

        JSONArray addressArray = personJson.getJSONArray("address");
        address = new ArrayList<>();

        addressArray.forEach(a -> {
            address.add(new Address((JSONObject) a));
        });
    }

    @Override
    public String toString() {
        String str = "Name -> " + name + "\nage -> " + age + "\nAddress ->";
        for (Address a : address)
            str += "\n\t" + a.toString();
        return str;
    }
}
