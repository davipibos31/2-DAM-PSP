import org.json.JSONObject;
import org.json.JSONTokener;

public class APIorgjsonAPP {

    public static void main(String[] args) {
        GetServiceResponse resp = new GetServiceResponse("http://localhost/services/example");
        String json = resp.getResponse();

        if (json != null) {
            //	We load the main (root) object
            JSONObject object = (JSONObject) new JSONTokener(resp.getResponse()).nextValue();
            if (!object.getBoolean("error")) {
                Person p = new Person(object.getJSONObject("person"));
                System.out.println(p.toString());
            } else {
                System.out.println("There was an error in the request");
            }
        }
    }

}
