public class GetServiceResponse {
	boolean error; // In JSON it will be named "error"
	ServiceUtils resp;

	public GetServiceResponse(String s) {
		resp = new ServiceUtils();
	}

	public boolean getError() {
		return error;
	}
	
	public String getResponse() {
		return resp.getResponse("http://localhost/services/example", null, "GET");
	}
}
