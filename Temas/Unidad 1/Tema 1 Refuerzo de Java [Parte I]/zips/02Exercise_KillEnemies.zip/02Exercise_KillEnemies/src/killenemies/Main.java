package killenemies;


import java.util.ArrayList;
import java.util.Collections;

public class Main {

	public static void main(String[] args) {
		ArrayList<Character> list = new ArrayList<>(10);
		
		for (int i = 0; i < 5; i++)
			list.add(new Enemy());
		
		for (int i = 0; i < 5; i++)
			list.add(new Friend());
		
		Collections.shuffle(list);
		
                int cont=0;
                for (Character c: list)
                {
                    if (c.isEnemy())
                    {
                        System.out.println("Character " + cont + " is an enemy! kill it!");
                        ((Enemy)c).kill();
                    }
                    else
                        System.out.println("Character " + cont + " is a friend! :-)");
                    cont++;
                }
	}
}
