package killenemies;

public class Friend implements Character {

	@Override
	public boolean isEnemy() {
		return false;
	}

}
