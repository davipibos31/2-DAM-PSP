public class Student implements ISayHello, ISayGoodbye {
    @Override
    public void sayGoodbye() {
        System.out.println("Hello, I'm a student!");
    }

    @Override
    public void sayHello() {
        System.out.println("Goodbye people!");
    }
}
