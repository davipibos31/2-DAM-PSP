public class Main {
    public static void main(String[] args) {
        ComputerClassroom compClass = new ComputerClassroom(30, 20);
        System.out.println("Students max.: " + compClass.getMaxStudents()
                + ", computers: " + compClass.getNumComputers());

        // MAIN
        ISayThings sayThings = new ISayThings() {
            private String name = "Peter";

            @Override
            public void sayHello() {
                System.out.println("Hello, my name is " + name);
            }

            @Override
            public void sayGoodbye() {
                System.out.println("Goodbye friends!");
            }
        };
    }
}
