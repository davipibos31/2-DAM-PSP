public class ComputerClassroom extends Classroom{
    private int numComputers;

    public ComputerClassroom(int maxStudents, int numComputers) {
        super(maxStudents);
        this.numComputers = numComputers;
    }

    public int getNumComputers() {
        return numComputers;
    }
}
