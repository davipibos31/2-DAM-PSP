public interface ISayThings extends ISayHello, ISayGoodbye {
    // Includes methods from ISayHello and ISayGoodbye.
}