public class Classroom {
    private int maxStudents;

    public Classroom(int maxStudents) {
        this.maxStudents = maxStudents;
    }

    public int getMaxStudents() {
        return maxStudents;
    }
}