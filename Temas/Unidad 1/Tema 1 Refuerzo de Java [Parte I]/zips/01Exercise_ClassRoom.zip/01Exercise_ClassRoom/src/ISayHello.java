public interface ISayHello {
    public void sayHello();
}
