public interface ISayGoodbye {
    public void sayGoodbye();
}
