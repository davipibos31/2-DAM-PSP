
public abstract class Shape {
    protected double area;

    public Shape() {
    }

    public abstract double getArea();
}
