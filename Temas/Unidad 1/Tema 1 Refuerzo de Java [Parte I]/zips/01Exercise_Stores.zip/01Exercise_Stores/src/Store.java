
public abstract class Store {
	private double cash, drinkPrice;
	
	public Store(double drinkPrice) {
		this.drinkPrice = drinkPrice;
		this.cash = 0.0;
	}
	
	public abstract void welcome();
	
	public void payDrinks(int numOfDrinks) {
		addCash(numOfDrinks * drinkPrice);
	}

	public double getDrinkPrice() {
		return drinkPrice;
	}

	public double getCash() {
		return cash;
	}

	public void addCash(double cash) {
		this.cash += cash;
	}
}
