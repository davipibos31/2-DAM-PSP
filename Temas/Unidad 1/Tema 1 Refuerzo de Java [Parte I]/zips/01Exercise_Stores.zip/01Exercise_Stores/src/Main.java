
public class Main {

	public static void main(String[] args) {
		Store liq = new LiquorStore(8.95, 20);
		liq.welcome();
		liq.payDrinks(10);
		System.out.printf("Total cash: %.2f€\n", liq.getCash());
		
		Store store = new Store(8.95) {
			
			@Override
			public void welcome() {
				System.out.printf("Welcome to anonymous store!, Our drink price is %.2f€\n", 
						getDrinkPrice());
			}
		};

		store.welcome(); // Will be treated as a Store inside
		store.payDrinks(10);
		System.out.printf("Total cash: %.2f€\n", store.getCash());

	}
}