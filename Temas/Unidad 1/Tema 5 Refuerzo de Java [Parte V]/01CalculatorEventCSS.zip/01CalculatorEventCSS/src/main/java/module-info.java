module com.example.calculatoreventcss {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.calculatoreventcss to javafx.fxml;
    exports com.example.calculatoreventcss;
}