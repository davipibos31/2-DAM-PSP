package com.example.fx2dgame;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class FX2DGame extends Application {

    private Set<KeyCode> activeKeys;

    // v.2.0
    @Override
    public void start(Stage stage) throws Exception {
        StackPane root = new StackPane();
        Scene scene = new Scene(root, 400, 200);

        Canvas canvas = new Canvas(400, 200);
        root.getChildren().add(canvas);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        Sprite img;
        Image lambda;
        try {
            img = new Sprite(200, 100, 50, 50,
                    new Image(Files.newInputStream(Paths.get("image.png"))));
            lambda = new Image(Files.newInputStream(Paths.get("lambda.png")));
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        activeKeys = new HashSet<>();
        scene.setOnKeyPressed(e -> activeKeys.add(e.getCode()));
        scene.setOnKeyReleased(e -> activeKeys.remove(e.getCode()));

        scene.setOnMouseClicked(e -> {
            img.setX((int) e.getX() - 25); // Image is 50x50
            img.setY((int) e.getY() - 25);
        });

        // Random lambda sprites
        Random rand = new Random(System.nanoTime());
        List<Sprite> lambdas = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            lambdas.add(new Sprite(rand.nextInt(350), rand.nextInt(150),
                    50, 50, lambda));
        }

        // Game loop
        new AnimationTimer() {
            public void handle(long currentNanoTime) {
                if (activeKeys.contains(KeyCode.RIGHT))
                    img.setX(img.getX() + 1);
                if (activeKeys.contains(KeyCode.LEFT))
                    img.setX(img.getX() - 1);
                if (activeKeys.contains(KeyCode.UP))
                    img.setY(img.getY() - 1);
                if (activeKeys.contains(KeyCode.DOWN))
                    img.setY(img.getY() + 1);

                // collision detection
                Iterator<Sprite> lambdasIter = lambdas.iterator();
                while (lambdasIter.hasNext()) {
                    Sprite lambda = lambdasIter.next();
                    if (lambda.intersects(img)) {
                        lambdasIter.remove();
                    }
                }

                gc.setFill(Color.WHITE);
                gc.fillRect(0, 0, 400, 200);
                for (Sprite lambda : lambdas)
                    lambda.draw(gc);
                img.draw(gc);

                if (lambdas.isEmpty())
                    this.stop();
            }
        }.start();

        stage.setTitle("2D Game Example");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}