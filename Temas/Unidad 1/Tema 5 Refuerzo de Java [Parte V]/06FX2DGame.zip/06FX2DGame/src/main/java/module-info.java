module com.example.fx2dgame {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.fx2dgame to javafx.fxml;
    exports com.example.fx2dgame;
}