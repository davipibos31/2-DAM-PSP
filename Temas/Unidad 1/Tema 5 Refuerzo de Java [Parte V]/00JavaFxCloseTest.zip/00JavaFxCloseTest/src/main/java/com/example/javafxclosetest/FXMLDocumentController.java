package com.example.javafxclosetest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class FXMLDocumentController implements Initializable {
    @FXML
    private Label label;
    @FXML
    private Button btnSfQuit;

    boolean isSafe = false;
    Stage stage;

    @FXML
    private void handleButtonAction(ActionEvent event) {
        isSafe = true;
        this.stage.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void setOnCloseListener(Stage stage) {
        this.stage = stage;
        this.stage.setOnCloseRequest(e -> {
            if (!isSafe)
                e.consume();
        });
    }
}