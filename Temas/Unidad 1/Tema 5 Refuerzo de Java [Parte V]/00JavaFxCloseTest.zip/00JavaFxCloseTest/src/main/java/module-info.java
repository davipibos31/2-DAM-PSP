module com.example.javafxclosetest {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.javafxclosetest to javafx.fxml;
    exports com.example.javafxclosetest;
}