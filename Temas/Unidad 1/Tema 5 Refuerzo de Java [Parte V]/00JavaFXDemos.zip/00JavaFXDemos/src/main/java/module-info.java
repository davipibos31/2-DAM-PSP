module com.example.javafxdemos {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.javafxdemos to javafx.fxml;
    exports com.example.javafxdemos;
}