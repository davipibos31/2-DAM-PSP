module com.example.temperatures {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.temperatures to javafx.fxml;
    exports com.example.temperatures;
}