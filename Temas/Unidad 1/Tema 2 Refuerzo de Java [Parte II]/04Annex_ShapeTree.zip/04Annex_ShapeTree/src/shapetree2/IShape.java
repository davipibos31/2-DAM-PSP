package shapetree2;


public interface IShape extends Comparable <IShape>
{
	public double getArea();
        
}
