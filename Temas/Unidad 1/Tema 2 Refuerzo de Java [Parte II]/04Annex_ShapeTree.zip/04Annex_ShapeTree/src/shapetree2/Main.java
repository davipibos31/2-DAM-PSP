/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package shapetree2;

import java.util.Set;
import java.util.TreeSet;

/**
 * Class comment
 */
public class Main 
{
    public static void main(String[] args) 
    {
        Set<IShape> set = new TreeSet<>();
        
        set.add(new Triangle(6.25, 8));
        set.add(new Triangle(7.2, 6.78));
        set.add(new Circle(4.3));
        set.add(new Circle(1.88));
        set.add(new Rectangle(9.25, 7.6));
        set.add(new Rectangle(9, 2.55));

        for(IShape s: set) {
                System.out.println(s.toString());
        }
    }
}
