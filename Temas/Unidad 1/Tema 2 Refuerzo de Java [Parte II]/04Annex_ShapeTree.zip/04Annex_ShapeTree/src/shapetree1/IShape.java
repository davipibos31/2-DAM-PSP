package shapetree1;


public interface IShape 
{
	public double getArea();
}
