package com.example.notepadjavafx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;

public class Controller {
    @FXML
    private MenuItem menuOpen;

    @FXML
    private MenuItem menuSave;

    @FXML
    private MenuItem menuExit;

    @FXML
    private TextArea txtContents;

    @FXML
    private Label lblResult;

    @FXML
    void pushExit(ActionEvent event) {
        System.exit(0);
    }

    public void initialize() {
        // TODO
    }
}