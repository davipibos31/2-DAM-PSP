module com.example.animationcredits {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.animationcredits to javafx.fxml;
    exports com.example.animationcredits;
}