package com.example.animationcredits;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.util.Duration;

public class Controller {
    @FXML
    private Label lblName;

    public void initialize() {
        // Transition
        TranslateTransition t = new TranslateTransition(Duration.millis(5000), lblName);
        t.setFromX(-300);
        t.setToX(400);
        t.setCycleCount(Timeline.INDEFINITE);
        t.play();
    }
}