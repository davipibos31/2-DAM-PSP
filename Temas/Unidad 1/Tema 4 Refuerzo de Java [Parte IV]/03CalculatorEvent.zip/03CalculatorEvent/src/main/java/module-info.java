module com.example.calculatorevent {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.calculatorevent to javafx.fxml;
    exports com.example.calculatorevent;
}