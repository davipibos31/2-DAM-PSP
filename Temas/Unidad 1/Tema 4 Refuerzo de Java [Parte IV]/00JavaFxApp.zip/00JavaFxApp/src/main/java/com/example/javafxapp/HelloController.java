package com.example.javafxapp;

import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.util.Duration;

public class HelloController {
    @FXML
    private Label label1;
    @FXML
    private Button button1;

    @FXML
    private Label lbl;

    public void initialize() {
        lbl.setText("HOLA!!");

        // Inside some method:
        TranslateTransition t = new TranslateTransition(Duration.millis(3000), lbl);
        t.setFromX(0);
        t.setFromY(0);
        t.setToX(300);
        t.setToY(0);
        t.play();
    }

    @FXML
    protected void onHelloButtonClick() {
        label1.setText("Welcome to JavaFX Application!");
    }
}