module com.example.growingbutton {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.growingbutton to javafx.fxml;
    exports com.example.growingbutton;
}