package unit1_extra_exercise;

import java.util.*;

public class Unit1_Extra_Exercise 
{
    public static void main(String[] args) 
    {
        List<Product> products = new ArrayList<>();
        
        products.add(new Product("Assassin's Creed", "Videogames", 19.95f));
        products.add(new Product("MacBook Air 13\"", "Laptops", 1195));
        products.add(new Product("Lenovo Yoga 14\"", "Laptops", 549.95f));
        products.add(new Product("BQ Curie 8\"", "Tablets", 69.45f));
        products.add(new Product("Samsung Galaxy Tab 3 9.7\"", "Tablets", 210.25f));
        products.add(new Product("iPad Mini 3", "Tablets", 399.95f));
        products.add(new Product("Microsoft Surface 3", "Tablets", 419.75f));
        products.add(new Product("The Lasf of Us", "Videogames", 49.95f));
        products.add(new Product("Fifa 17", "Videogames", 69.95f));
    }
}
