
/**
 * @author Alvaro
 */
public class Person implements Comparable<Person> {
    private String name;

    public Person(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return this.name;
    }

    public String getName() {
        return this.name;
    }

    @Override
    public int compareTo(Person t) {
        return this.name.compareTo(t.getName());
    }
}
