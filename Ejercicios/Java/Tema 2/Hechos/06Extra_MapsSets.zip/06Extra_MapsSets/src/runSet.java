/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.HashSet;
import java.util.TreeSet;

/**
 * @author Alvaro
 */
public class runSet {

    public static void main(String[] args) {

        HashSet<Person> set = new HashSet<Person>();

        set.add(new Person("Nacho"));
        set.add(new Person("Alvaro"));
        set.add(new Person("Javier"));
        set.add(new Person("Alvaro"));

        for (Person p : set)
            System.out.println(p.toString());


        System.out.println("TreeSet example ------");
        System.out.println("No repeats elements and orders the elements (using Comparable interface)");

        TreeSet<Person> tree = new TreeSet<Person>();

        tree.add(new Person("Nacho"));
        tree.add(new Person("Alvaro"));
        tree.add(new Person("Javier"));
        tree.add(new Person("Alvaro"));

        for (Person p : tree)
            System.out.println(p.toString());
    }

}
