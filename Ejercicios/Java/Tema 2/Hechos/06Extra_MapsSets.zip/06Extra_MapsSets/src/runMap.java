/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.HashMap;
import java.util.Map;

/**
 * @author Alvaro
 */
public class runMap {

    public static void main(String[] args) {

        HashMap<String, Person> map = new HashMap<String, Person>();

        map.put("1", new Person("Alvaro"));
        map.put("2", new Person("Nacho"));
        map.put("22", new Person("Fernando"));
        map.put("200", new Person("Javier"));

        System.out.println(map);
        map.remove("22");
        System.out.println(map);

        for (Map.Entry<String, Person> p : map.entrySet()) {
            String key = p.getKey();
            Person person = p.getValue();
            System.out.println(key + " --> " + person.toString());
        }
    }

}


